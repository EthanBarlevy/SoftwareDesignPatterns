﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NullObject
{
	internal class BostonDynamics : Robot
	{
		public override void Speak()
		{
            Console.WriteLine("i am going to destroy the earth.");
        }
	}
}
