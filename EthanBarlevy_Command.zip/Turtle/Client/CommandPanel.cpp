#include "CommandPanel.h"

ITurtle* CommandPanel::GetTurtle()
{
    return new Turtle();
}
